# crypto_j_trader/src/trading/exceptions.py
class InsufficientLiquidityError(Exception):
    pass

class ValidationError(Exception):
    pass